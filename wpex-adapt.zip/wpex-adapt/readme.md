# Adapt WordPress Theme
Developed by WPExplorer.com
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

## Liability
WPExplorer.com shall not be held liable for any damages, including, but not limited to, the loss of data or profit, arising from the use of, or inability to use, this theme.

## Bug Report
Please submit any bug reports to the public repository - https://github.com/wpexplorer/wpex-adapt/issues

This is a Free community driven theme so if you find an issue we highly request that you fix the issue and submit a pull-request so we can update the theme accordingly. Thanks!