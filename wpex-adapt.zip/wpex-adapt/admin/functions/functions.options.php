<?php
/**
 * Create options for this theme
 *
 * @package WordPress
 * @subpackage Adapt
 * @since Adapt 1.0
 */